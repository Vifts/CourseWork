package magicsquares;

import java.util.Scanner;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Frank Wiltbank
 */
public class MagicSquares {

    private static String output = new String();
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
                
        System.out.println("Enter the type of input for the game:");
        System.out.println("(1)  Input magic values from file");
        System.out.println("(2)  Construct magic squares from input size and write to file");
        System.out.println("(3)  Exit the program");

        int inputMenu = sc.nextInt();

        while (inputMenu != 3) {
            switch (inputMenu) {
                case 1:
                    MagicSquares.inputMagicValues();
                    break;
                case 2:
                    MagicSquares.constructMagicSquare();
                    break;
            }
            System.out.println("");
            System.out.println("Enter the type of input for the game:");
            System.out.println("(1)  Input magic values from file");
            System.out.println("(2)  Construct magic squares from input size and write to file");
            System.out.println("(3)  Exit the program");
        }
        

    }
   
    public static void inputMagicValues() {

        Scanner sc = new Scanner(System.in);
        int num = 0;
        int inputArray[] = new int[100];
        int row = 0;
        int col = 0;

        System.out.println("Enter a file name");
        String fname = sc.nextLine();
        java.io.File file = new java.io.File(fname);

         // Create a Scanner for the file
        try {
            Scanner input = new Scanner(file);

            while (input.hasNext()) {
                inputArray[num] = input.nextInt();
                num++;
            }
            input.close();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(MagicSquares.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        boolean validCount = false; 
        for (int i = 1; i <= 10; i++)
        {
            if(num == (i * i))
                validCount=true;
        }
        
        int checkArray[] = new int[num];
        for (int i = 0; i < num; i++)
        {
           checkArray[i]=inputArray[i];
        }
        
        java.util.Arrays.sort(checkArray);
        int validNums = 0;
        
        for (int i = 0; i < num; i++)
        {
           if (checkArray[i] == (i+1))
               validNums++;
        }
        
        if (validCount == true && validNums == num)
        {
            int[][] matrix = new int[(int) Math.sqrt(num)][(int) Math.sqrt(num)];
            
             for (row = 0; row < matrix.length; row++)
            {
                for (col = 0; col < matrix[row].length; col++)
                {
                    matrix[row][col]=inputArray[row*matrix.length + col];
                }
                
            }
             
            // check row, col and diag sums here
            int []arrayRow = new int[(int) Math.sqrt(num)];
            int []arrayCol = new int[(int) Math.sqrt(num)];
            //int []arrayDiag = new int[2]; ?????
            int total = 0;
            boolean arraySums = false;
            
            //row
            for (row = 0; row < matrix.length; row++)
            {
                for (col = 0; col < matrix[row].length; col++)
                {
                    arrayRow[row] += matrix[row][col];
                }
            } 
            
            //col
            for (col = 0; col < matrix.length; col++)
                
            {
               for (row = 0; row < matrix.length; row++)
                {
                    arrayCol[col]+=matrix[row][col];
                }
            }
            //diag
            for (int index = 0; index < matrix.length; index++)
            {
                total += matrix[index][index];
            }   
              
            //print matrix
            for (row = 0; row < matrix.length; row++)
            {
                for (col = 0; col < matrix[row].length; col++)
                {
                    System.out.print(matrix[row][col] + "  ");
                }
                System.out.println();
            }
        }
        
        else System.out.println("Invalid");
        
        
        
    } 
    public static void constructMagicSquare() {
        Scanner sc = new Scanner(System.in);
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter a file name to store results");
        String fname2 = sc.nextLine();
        java.io.File file = new java.io.File(fname2);
        
        System.out.println("Enter a number to construct a magic square");

        int k = 0;
        if (k % 2 == 0) 
        {
           System.out.println("Number must be odd"); 
        }
        k = sc.nextInt();
        
        int row = k - 1;
        int col = k / 2;
        int inputArray[] = new int[100];
        int magicSquare[][] = new int[k][k];
        magicSquare[row][col] = 1;
        
        

        for (int i = 2; i<= k * k; i++)
        {
            if (magicSquare[(row + 1) % k][(col + 1) % k] == 0)
            {
                row = (row + 1) % k;
                col = (col + 1) % k;
            }
            else //column stays the same
            {
                row = (row - 1 + k) % k;
            }
            magicSquare[row][col] = i;
        }
        //save results
        for (int i = 0; i < k; i++)
        {
            for (int j = 0; j < k; j++)
            {
                //align square
                if (magicSquare[i][j] < 10)
                {
                    System.out.print(" ");
                }
                if (magicSquare[i][j] < 100)
                {
                    System.out.print(" ");
                }
                System.out.print(magicSquare[i][j] + " ");
            }
            System.out.println();
        }
        input.close();
    }
}
