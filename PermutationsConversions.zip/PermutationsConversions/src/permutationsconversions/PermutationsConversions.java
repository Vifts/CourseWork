
package permutationsconversions;

// @author Frank Wiltbank

import java.util.Scanner;


public class PermutationsConversions {

    public static void main(String[] args) 
    {
        PermutationsConversions pc = new PermutationsConversions();
        Scanner sc = new Scanner(System.in);
        
        String s1 = new String();
        String s2 = new String();
        String s3 = new String();
        String binary = new String();
        
        //give user directions
        System.out.println("Enter the type of algorithm to execute: ");
        System.out.println("1: Permutation");
        System.out.println("2: Conversion");
        System.out.println("3: Exit the program");
        
        int alg = sc.nextInt();
        switch (alg) 
        {
            //start permutation of strings
            case 1:
                 pc.permute(s1,s2,s3);
                break;
                
            //start binary conversion    
            case 2:
                pc.convert(binary);
                break;
                
            //exit program    
            case 3:
                break;
        }
    }
    
    public void permute (String a, String b, String c)
    {
        //get input
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 3 strings");
            a = sc.nextLine(); 
            b = sc.nextLine();
            c = sc.nextLine();
        //print result         
        System.out.println(a + b + c);
        System.out.println(a + c + b);
        System.out.println(b + a + c);
        System.out.println(b + c + a);
        System.out.println(c + a + b);
        System.out.println(c + b + a);
    }
    
    public void convert (String binary)
    {
        //get input
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a binary number");
        binary = sc.nextLine();
        //print result
        System.out.println("Conversion: " + Integer.parseInt(binary,2));
        
        
    }
}

// Could not figure out how to properly error check
