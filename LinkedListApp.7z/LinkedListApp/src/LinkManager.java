/*
 * LinkManager.java
 *
 */

import java.lang.*;
import java.util.*;
import java.io.*;
import javax.swing.JOptionPane;

public class LinkManager {

    LinkNode head = null;
    LinkedApplication myApp;

    /**
     * Creates a new instance of LinkManager
     */
    public LinkManager(LinkedApplication a) {
        myApp = a;
    }

    public boolean initialize(String fileName) {
        try {
            BufferedReader inStream // Create and 
                    = new BufferedReader(new FileReader(fileName)); // Open the stream
            String name = "";
            String title = "";
            int sal = 0;
            int years = 0;
            String line = inStream.readLine();            // Read one line

            while (line != null) {                        // While more text

                name = line;

                line = inStream.readLine();               // Read next line
                title = line;

                line = inStream.readLine();               // Read next line
                sal = Integer.parseInt(line);

                line = inStream.readLine();               // Read next line
                years = Integer.parseInt(line);

                LinkNode tempNode = new LinkNode(name, title, sal, years);
                insert(tempNode);

                line = inStream.readLine();            // Read one line
            }
            inStream.close();   // Close the stream
            return true;
        } catch (java.io.FileNotFoundException e) {
            myApp.displayText("IOERROR: File NOT Found: " + fileName + "\n");
            return false; // invalid operation
            //e.printStackTrace();
        } catch (java.io.IOException e) {
            myApp.displayText("IOERROR: " + e.getMessage() + "\n");
            return false; // invalid operation
            //e.printStackTrace();
        }
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void insert(LinkNode newNode) {
        if (isEmpty()) {
            head = newNode;                   // Insert at head of list
        } else {
            LinkNode current = head;   // Start traversal at head
            while (current.getNext() != null) // While not at the last node
            {
                current = current.getNext();  //   go to the next node
            }
            current.setNext(newNode);     // Do the insertion
        }
    } // insert()

    public String print() {

        if (isEmpty()) {
            return "List is empty";
        }

        String listContents = "";
        LinkNode current = head;          // Start traversal at head

        while (current != null) {                     // While not at end of list
            listContents = listContents + current.getInfo() + "\n"; //   append node's data to string
            current = current.getNext();              //   go to the next node
        }
        return listContents;

    } // print()

    public void sortByYears() {
        LinkNode sortedYearHead = null; //start of new list
        LinkNode current = head; //pointer to current node
        LinkNode temp; //keep track of next node to be placed from the current list
        LinkNode prevNode; //keep track of the node before nextNode
        LinkNode nextNode; //keep track of the node after prevNode

        while (current != null) {
            if (sortedYearHead == null) //if there are no nodes in the new list
            {
                sortedYearHead = current; //set location to new node
                head = current; //assign head of list to current node
                temp = current.getNext(); //remember first node in the rest of the original list
                current.setNext(null); //remove link to current list
                current = temp; //set current back to next node to be placed to keep loop active
            }//end if
            else if (current.getYears() < head.getYears()) //place node at front
            {
                temp = current.getNext(); //keep rest of the original list
                head = current; //place new node at the head of the list
                head.setNext(sortedYearHead); //attach rest of new list
                sortedYearHead = head; //reassign new sortedYearHead
                current = temp; //set current back to next node to be placed to keep loop active
            } else //node needs to be placed at middle or end of the list
            {
                temp = current.getNext(); //keep rest of the original list
                prevNode = sortedYearHead; //set prevNode to head of list
                nextNode = sortedYearHead.getNext(); //set nextNode to node after head

                //walk through list to determine location for new node. Should be placed
                //between previous node and next node
                while ((nextNode != null) && (current.getYears() > nextNode.getYears())) {
                    prevNode = nextNode;
                    nextNode = nextNode.getNext();

                }
                //place at end of the list
                if (nextNode == null) {
                    prevNode.setNext(current); //add to end of the list
                    current.setNext(null); //
                    current = temp; //set current back to next node to be placed to keep loop active
                } else //place new node between prev and next
                {
                    prevNode.setNext(current);
                    current.setNext(nextNode);
                    current = temp; //set current back to next node to be placed to keep loop active
                }
            }
        }
    }

    public void sortByName() {
        LinkNode sortedNameHead = null; //start of new list
        LinkNode current = head; //pointer to current node
        LinkNode temp; //keep track of next node to be placed from the current list
        LinkNode prevNode; //keep track of the node before nextNode
        LinkNode nextNode; //keep track of the node after prevNode

        while (current != null) {
            if (sortedNameHead == null) //if there are no nodes in the new list
            {
                sortedNameHead = current; //set location to new node
                head = current; //assign head of list to current node
                temp = current.getNext(); //remember first node in the rest of the original list
                current.setNext(null); //remove link to current list
                current = temp; //set current back to next node to be placed to keep loop active
            }//end if
            else if (current.getName().compareTo(head.getName()) < 0) //place node at front
            {
                temp = current.getNext(); //keep rest of the original list
                head = current; //place new node at the head of the list
                head.setNext(sortedNameHead); //attach rest of new list
                sortedNameHead = head; //reassign new sortedNameHead
                current = temp; //set current back to next node to be placed to keep loop active
            } else //node needs to be placed at middle or end of the list
            {
                temp = current.getNext(); //keep rest of the original list
                prevNode = sortedNameHead; //set prevNode to head of list
                nextNode = sortedNameHead.getNext(); //set nextNode to node after head

                //walk through list to determine location for new node. Should be placed
                //between previous node and next node
                while ((nextNode != null) && (current.getName().compareTo(nextNode.getName()) > 0)) {
                    prevNode = nextNode;
                    nextNode = nextNode.getNext();

                }
                //place at end of the list
                if (nextNode == null) {
                    prevNode.setNext(current); //add to end of the list
                    current.setNext(null); //
                    current = temp; //set current back to next node to be placed to keep loop active
                } else //place new node between prev and next
                {
                    prevNode.setNext(current);
                    current.setNext(nextNode);
                    current = temp; //set current back to next node to be placed to keep loop active
                }
            }
        }
    }

    public void sortBySalary() {
        LinkNode sortedSalaryHead = null; //start of new list
        LinkNode current = head; //pointer to current node
        LinkNode temp; //keep track of next node to be placed from the current list
        LinkNode prevNode; //keep track of the node before nextNode
        LinkNode nextNode; //keep track of the node after prevNode

        while (current != null) {
            if (sortedSalaryHead == null) //if there are no nodes in the new list
            {
                sortedSalaryHead = current; //set location to new node
                head = current; //assign head of list to current node
                temp = current.getNext(); //remember first node in the rest of the original list
                current.setNext(null); //remove link to current list
                current = temp; //set current back to next node to be placed to keep loop active
            }//end if
            else if (current.getSalary() > head.getSalary()) //place node at front
            {
                temp = current.getNext(); //keep rest of the original list
                head = current; //place new node at the head of the list
                head.setNext(sortedSalaryHead); //attach rest of new list
                sortedSalaryHead = head; //reassign new sortedYearHead
                current = temp; //set current back to next node to be placed to keep loop active
            } else //node needs to be placed at middle or end of the list
            {
                temp = current.getNext(); //keep rest of the original list
                prevNode = sortedSalaryHead; //set prevNode to head of list
                nextNode = sortedSalaryHead.getNext(); //set nextNode to node after head

                //walk through list to determine location for new node. Should be placed
                //between previous node and next node
                while ((nextNode != null) && (current.getSalary() <= nextNode.getSalary())) {
                    prevNode = nextNode;
                    nextNode = nextNode.getNext();
                }
                //place at end of the list
                if (nextNode == null) {
                    prevNode.setNext(current); //add to end of the list
                    current.setNext(null); //
                    current = temp; //set current back to next node to be placed to keep loop active
                } else //place new node between prev and next
                {
                    prevNode.setNext(current);
                    current.setNext(nextNode);
                    current = temp; //set current back to next node to be placed to keep loop active
                }
            }
        }
    }

    public void sortByTitle() {
        LinkNode sortedTitleHead = null; //start of new list
        LinkNode current = head; //pointer to current node
        LinkNode temp; //keep track of next node to be placed from the current list
        LinkNode prevNode; //keep track of the node before nextNode
        LinkNode nextNode; //keep track of the node after prevNode

        while (current != null) {
            if (sortedTitleHead == null) //if there are no nodes in the new list
            {
                sortedTitleHead = current; //set location to new node
                head = current; //assign head of list to current node
                temp = current.getNext(); //remember first node in the rest of the original list
                current.setNext(null); //remove link to current list
                current = temp; //set current back to next node to be placed to keep loop active
            }//end if
            else if (current.getTitle().compareTo(head.getTitle()) < 0) //place node at front
            {
                temp = current.getNext(); //keep rest of the original list
                head = current; //place new node at the head of the list
                head.setNext(sortedTitleHead); //attach rest of new list
                sortedTitleHead = head; //reassign new sortedNameHead
                current = temp; //set current back to next node to be placed to keep loop active
            } else //node needs to be placed at middle or end of the list
            {
                temp = current.getNext(); //keep rest of the original list
                prevNode = sortedTitleHead; //set prevNode to head of list
                nextNode = sortedTitleHead.getNext(); //set nextNode to node after head

                //walk through list to determine location for new node. Should be placed
                //between previous node and next node
                while ((nextNode != null) && (current.getTitle().compareTo(nextNode.getTitle()) > 0)) {
                    prevNode = nextNode;
                    nextNode = nextNode.getNext();

                }
                //place at end of the list
                if (nextNode == null) {
                    prevNode.setNext(current); //add to end of the list
                    current.setNext(null); //
                    current = temp; //set current back to next node to be placed to keep loop active
                } else //place new node between prev and next
                {
                    prevNode.setNext(current);
                    current.setNext(nextNode);
                    current = temp; //set current back to next node to be placed to keep loop active
                }
            }
        }
    }

    public void sortByTitleSalary() {
        LinkNode sortedSalaryHead = null; //start of new list
        LinkNode current = head; //pointer to current node
        LinkNode temp; //keep track of next node to be placed from the current list
        LinkNode prevNode; //keep track of the node before nextNode
        LinkNode nextNode; //keep track of the node after prevNode

        while (current != null) {
            if (sortedSalaryHead == null) //if there are no nodes in the new list
            {
                sortedSalaryHead = current; //set location to new node
                head = current; //assign head of list to current node
                temp = current.getNext(); //remember first node in the rest of the original list
                current.setNext(null); //remove link to current list
                current = temp; //set current back to next node to be placed to keep loop active
            }//end if
            else if (current.getSalary() > head.getSalary()) //place node at front
            {
                temp = current.getNext(); //keep rest of the original list
                head = current; //place new node at the head of the list
                head.setNext(sortedSalaryHead); //attach rest of new list
                sortedSalaryHead = head; //reassign new sortedYearHead
                current = temp; //set current back to next node to be placed to keep loop active
            } else //node needs to be placed at middle or end of the list
            {
                temp = current.getNext(); //keep rest of the original list
                prevNode = sortedSalaryHead; //set prevNode to head of list
                nextNode = sortedSalaryHead.getNext(); //set nextNode to node after head

                //walk through list to determine location for new node. Should be placed
                //between previous node and next node
                while ((nextNode != null) && (current.getSalary() <= nextNode.getSalary())) {
                    prevNode = nextNode;
                    nextNode = nextNode.getNext();
                }
                //place at end of the list
                if (nextNode == null) {
                    prevNode.setNext(current); //add to end of the list
                    current.setNext(null); //
                    current = temp; //set current back to next node to be placed to keep loop active
                } else //place new node between prev and next
                {
                    prevNode.setNext(current);
                    current.setNext(nextNode);
                    current = temp; //set current back to next node to be placed to keep loop active
                }
            }
        }
        LinkNode sortedTitleHead = null; //start of new list
        current = head; //pointer to current node
        temp = null; //keep track of next node to be placed from the current list
        prevNode = null; //keep track of the node before nextNode
        nextNode = null; //keep track of the node after prevNode

        while (current != null) {
            if (sortedTitleHead == null) //if there are no nodes in the new list
            {
                sortedTitleHead = current; //set location to new node
                head = current; //assign head of list to current node
                temp = current.getNext(); //remember first node in the rest of the original list
                current.setNext(null); //remove link to current list
                current = temp; //set current back to next node to be placed to keep loop active
            }//end if
            else if (current.getTitle().compareTo(head.getTitle()) < 0) //place node at front
            {
                temp = current.getNext(); //keep rest of the original list
                head = current; //place new node at the head of the list
                head.setNext(sortedTitleHead); //attach rest of new list
                sortedTitleHead = head; //reassign new sortedNameHead
                current = temp; //set current back to next node to be placed to keep loop active
            } else //node needs to be placed at middle or end of the list
            {
                temp = current.getNext(); //keep rest of the original list
                prevNode = sortedTitleHead; //set prevNode to head of list
                nextNode = sortedTitleHead.getNext(); //set nextNode to node after head

                //walk through list to determine location for new node. Should be placed
                //between previous node and next node
                while ((nextNode != null) && (current.getTitle().compareTo(nextNode.getTitle()) >= 0)) {
                    prevNode = nextNode;
                    nextNode = nextNode.getNext();

                }
                //place at end of the list
                if (nextNode == null) {
                    prevNode.setNext(current); //add to end of the list
                    current.setNext(null); //
                    current = temp; //set current back to next node to be placed to keep loop active
                } else //place new node between prev and next
                {
                    prevNode.setNext(current);
                    current.setNext(nextNode);
                    current = temp; //set current back to next node to be placed to keep loop active
                }
            }
        }
    }

    public void addNode(String name, String yrs, String title, String sal) {
        try {
            int years = Integer.parseInt(yrs);
            int salary = Integer.parseInt(sal);
            LinkNode tempNode = new LinkNode(name, title, salary, years);
            insert(tempNode);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Invalid Data", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void removeNode(String name, String yrs, String title, String sal) {

        try {
            int yearsEmp = Integer.parseInt(yrs);
            int jobSalary = Integer.parseInt(sal);
            LinkNode current = head; //pointer to current node
            LinkNode temp; //keep track of next node to be placed from the current list
            LinkNode prevNode = null; //keep track of the node before nextNode
            LinkNode nextNode; //keep track of the node after prevNode

            if (head == null) //if there are no nodes in the new list
            {
                JOptionPane.showMessageDialog(null, "List is Empty", "ERROR", JOptionPane.INFORMATION_MESSAGE);
            } else if (head.getName().equalsIgnoreCase(name) && head.getYears() == yearsEmp && head.getTitle().equalsIgnoreCase(title)
                    && head.getSalary() == jobSalary) {
                head = head.getNext();
            } else //node needs to be placed at middle or end of the list
            {
                while (current != null) {
                    if (current.getNext().getName().equalsIgnoreCase(name) && current.getNext().getYears() == yearsEmp
                            && current.getNext().getTitle().equalsIgnoreCase(title) && current.getNext().getSalary() == jobSalary) {
                        prevNode = current;
                        current = current.getNext();
                        break;
                    }
                    current = current.getNext();
                }
                prevNode.setNext(current.getNext());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Invalid Data", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
