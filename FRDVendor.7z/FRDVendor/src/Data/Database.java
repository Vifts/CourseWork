/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author abdiv
 */
public class Database {
    String databaseLocation = "jdbc:ucanaccess://D:/IST311/FRDVENDOR3/FinalProjectDatabase.accdb";
    String databaseLocation1 = "jdbc:ucanaccess://C:/Users/abdiv/OneDrive/Documents/NetBeansProjects/FRDVendor3/FRDVendor3/src/Data/Items.accdb";
    String database = "jdbc:ucanaccess://E:/IST 311/FRDVendorFinal/FRDVendor3/FRDVendor4/FRDVendor3/src/Data/Items.accdb";
    String driver = "net.ucanaccess.jdbc.UcanaccessDriver";
    
    public void createDatabase()
    {
        try
        {
            //load driver
            Class.forName(driver);
            
            //connect to db
            Connection conn = DriverManager.getConnection(database);
            Statement s = conn.createStatement();
            
            try
            {
            s.execute("DROP TABLE Inventory");
            s.execute("DROP TABLE Orders");
            }
            catch(Exception e)
            {
                System.out.println("Database has not yet been created");
            }
            
            try
            {
                s.execute("CREATE TABLE Inventory"
                        + "(InventoryId number, ItemName varchar(255),"
                        + "ItemSales number, ItemPrice number,"
                        + "ItemStock number)");
                
                s.execute("CREATE TABLE Orders"
                        + "(OrderId number, Order varchar(255))");
            }
            catch(Exception e)
            {
                System.out.println("Database error");
            }
            
            s.close();
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println("Could not connect to database");
        }
    }
    
    
    public double ItemPrice(String item){
        double price = 0.0;
        //load driver
        try{
           Class.forName(driver);
            
            //connect to db
            Connection conn = DriverManager.getConnection(database);
            PreparedStatement s = conn.prepareStatement("select * from itemPrice where Item Name = ?");
            s.setString(0, item);
         
            ResultSet rs = s.executeQuery();
            
            while(rs.next()){
                price = rs.getDouble("Price");
            }
        }
        catch(ClassNotFoundException | SQLException e)
        {
            System.out.println("Could not connect to database");
        }   
        return price;
    }
    
    
    public void addItemToDb(String itemName, int stock, int price)
    {
        try{
        //load driver
        Class.forName(driver);
        
        Connection conn = DriverManager.getConnection(database);
        Statement s = conn.createStatement();
        
        try{
            s.execute("INSERT INTO Inventory "
                    + "(ItemName, ItemSales, ItemPrice, ItemStock)"
                    + "Values"
                    + "("
                    + itemName
                    +", "
                    + Integer.toString(0)
                    +", "
                    +Integer.toString(price)
                    +","
                    +Integer.toString(stock)
                    +")"
                    );
        }
        catch(Exception e){
            System.out.println("Could not execute SQL statement");
        }
        s.close();
        conn.close();
        }
        catch(Exception e){
            System.out.println("Could not connect to database");
        }
    }
    
    public void restockInventory()
    {
        try
        {
            //load driver
            Class.forName(driver);
            
            //connect to db
            Connection conn = DriverManager.getConnection(database);
            Statement s = conn.createStatement();
            
            try
            {
                s.execute("UPDATE Inventory"
                        + "SET ItemStock = 50"
                        + "WHERE ItemStock < 10");
            }
            catch(Exception e)
            {
                System.out.println("Could not restock");
            }
            
            s.close();
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println("Could not connect to database");
        }
    }
    
    public double getTotalSales()
    {
        double result = 0;
        try
        {
            //load driver
            Class.forName(driver);
            
            //connect to db
            Connection conn = DriverManager.getConnection(database);
            Statement s = conn.createStatement();
            
            try
            {
               ResultSet rs = s.executeQuery("SELECT SUM(ItemSales)"
                        + "FROM Iventory");
               while (rs.next())
               {
                   result = rs.getDouble("SUM(ItemSales)");
               }
            }
            catch(Exception e)
            {
                System.out.println("Could not get total sales");
            }
            
            s.close();
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println("Could not connect to database");
        }
        return result;
    }
    
    public void minusInventory(String itemName, int numMinus)
    {
        try
        {
            //load driver
            Class.forName(driver);
            
            //connect to db
            Connection conn = DriverManager.getConnection(database);
            Statement s = conn.createStatement();
            
            try
            {
                s.execute("UPDATE Inventory"
                        + "SET ItemStock = ItemStock - "
                        + Integer.toString(numMinus)
                        + " "
                        + "WHERE ItemName = " + itemName);
            }
            catch(Exception e)
            {
                System.out.println("Coul not edit inventory");
            }
            
            s.close();
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println("Could not connect to database");
        }
    }
    //TODO DO THIS
    public void perItemSales()
    {
        try
        {
            //connect to db
            Class.forName(driver);
            
            //connect to db
            Connection conn = DriverManager.getConnection(database);
            Statement s = conn.createStatement();
            
            try
            {
                s.execute("");
            }
            catch(Exception e)
            {
                System.out.println("Could not get per item sales");
            }
            s.close();
            conn.close();
        }
        catch(Exception e)
        {
            System.out.println("Could not connect to database");
        }
    }
    //TODO FINISH THIS
    public void addOrderToDb(String itemname, String qunt, String tprice)
    {
        try
        {
            //load driver
            Class.forName(driver);
            
            //connect to db
            Connection conn = DriverManager.getConnection(database);
            Statement s = conn.createStatement();
            
            try
            {
                s.execute("INSERT INTO Sale (ItemName, Quantity, Price) VALUES ('" + itemname +"','" + qunt + "','" + tprice + "')");
                     
                s.close();
                conn.close();   
            }
         
            catch(Exception e)
            {
                System.out.println("Could not add order");
            }
          
        }
        catch(Exception e)
        {
            System.out.println("Could not connect to database");
        }
    }
}
